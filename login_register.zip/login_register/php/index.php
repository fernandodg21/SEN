<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar sesion</title>
    <link rel="stylesheet" href="style.css">
    <link rel="conexion" href="conexion.php">  
    <link rel="registro" href="C:\Users\lilia\.dbclient\storage\1729478820646@@127.0.0.1@3306@registro\registro.sql"> 
</head>
<body>
    <div>
    <div class="formulario">
        <h1>Inicio de sesion</h1>
        <form method="post">
            <div class="username">
                <input type="tex" required>
                <label>Usuario</label>
            </div>
            <div class="contrasena">
                <input type="password"required>
                <label>Contraseña</label>
            </div>
            <div class="recordar"></div>
                <a href="recuperar.html">Olvido la contraseña?</a>
            <input type="submit" value="Iniciar">
            <div class="registrarme">
               <a href="signup.html">Quiero registrarme</a>
              
                  </form>   

       
    </div>
</body>

    <img src="C:\Users\lilia\Downloads\ANALISIS Y DESARROLLO DE SOFTWARE\A VISUAL STUDIO CODE\imagenenvio.jpeg" width="350px" height="350" alt=""> </div>
    
    <div class="formulario">

            <h2>Bienvenido a sistema de Envio S-E-N </h1>
    </div>
</body>
</head>
</html>

