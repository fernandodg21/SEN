<?php


$connect = mysqli_connect("localhost","root", "", "login_register_db");

if($conexion){
    echo 'conectado exitosamente a la base de datos';
}else{
    echo'no se a podido conectar a la base de datos';
}

?>